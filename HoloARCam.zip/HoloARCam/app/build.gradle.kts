plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.holoar.cam"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.holoar.cam"
        minSdk = 26 // ARCore + MediaPipe Tasks need modern camera APIs
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    packaging {
        resources.excludes.add("META-INF/*")
    }
}

dependencies {
    // Core / Compose UI
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")

    // Camera passthrough is driven by ARCore's own camera texture (no separate CameraX pipeline needed)
    implementation("com.google.ar:core:1.44.0")

    // Hand landmark detection (heart gesture)
    implementation("com.google.mediapipe:tasks-vision:0.10.14")

    // Face detection (compliment engine) - on-device, nothing leaves the phone
    implementation("com.google.mlkit:face-detection:16.1.7")

    // Coroutines for background frame analysis
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
