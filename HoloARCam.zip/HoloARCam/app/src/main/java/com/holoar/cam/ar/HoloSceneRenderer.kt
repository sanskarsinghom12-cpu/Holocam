package com.holoar.cam.ar

import android.graphics.Bitmap
import androidx.lifecycle.LifecycleCoroutineScope
import com.google.ar.core.Frame
import com.google.ar.core.TrackingState
import com.holoar.cam.face.ComplimentEngine
import com.holoar.cam.gesture.HandTracker
import com.holoar.cam.gesture.HeartGestureDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/**
 * Callbacks the renderer fires back to the UI layer. Kept minimal and Compose-friendly:
 * the UI just holds this as mutable state and re-renders.
 */
interface HoloSceneListener {
    fun onHeartGesture(active: Boolean)
    fun onCompliment(text: String?)
    fun onTrackingState(tracking: Boolean)
    fun onArUnavailable()
}

class HoloSceneRenderer(
    private val arManager: ArManager,
    private val handTracker: HandTracker,
    private val complimentEngine: ComplimentEngine,
    private val scope: LifecycleCoroutineScope,
    private val listener: HoloSceneListener
) : android.opengl.GLSurfaceView.Renderer {

    private val backgroundRenderer = BackgroundRenderer()
    private val objectRenderer = HoloObjectRenderer()
    private val heartDetector = HeartGestureDetector()

    @Volatile var viewportWidth = 1
        private set
    @Volatile var viewportHeight = 1
        private set

    /** Updated every drawn frame on the GL thread; touch handling reads it via queueEvent. */
    @Volatile var latestFrame: Frame? = null
        private set

    private val startTime = System.nanoTime()
    private var frameCounter = 0
    private var analysisInFlight = false

    // How often (in rendered frames) we run the heavier hand/face analysis. At ~30fps
    // this is roughly 5 times per second -- plenty responsive for gestures/compliments
    // while keeping the GPU/CPU budget free for smooth AR rendering.
    private val analysisIntervalFrames = 6

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        android.opengl.GLES20.glClearColor(0f, 0f, 0f, 1f)
        backgroundRenderer.createOnGlThread()
        objectRenderer.createOnGlThread()
        arManager.session?.setCameraTextureName(backgroundRenderer.textureId)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width
        viewportHeight = height
        android.opengl.GLES20.glViewport(0, 0, width, height)
        arManager.setDisplayGeometry(width, height, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        val session = arManager.session ?: run {
            android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        session.setCameraTextureName(backgroundRenderer.textureId)

        val frame = try {
            session.update()
        } catch (e: Exception) {
            listener.onArUnavailable()
            return
        }
        latestFrame = frame
        backgroundRenderer.updateTransformedCoords(frame)

        android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT or android.opengl.GLES20.GL_DEPTH_BUFFER_BIT)
        backgroundRenderer.draw()

        val tracking = frame.camera.trackingState == TrackingState.TRACKING
        listener.onTrackingState(tracking)

        if (tracking) {
            val viewMatrix = FloatArray(16)
            val projMatrix = FloatArray(16)
            frame.camera.getViewMatrix(viewMatrix, 0)
            frame.camera.getProjectionMatrix(projMatrix, 0, 0.05f, 50f)
            val timeSeconds = (System.nanoTime() - startTime) / 1_000_000_000f
            objectRenderer.draw(arManager.objects, viewMatrix, projMatrix, timeSeconds)
        }

        maybeRunThrottledAnalysis(frame)
    }

    private fun maybeRunThrottledAnalysis(frame: Frame) {
        frameCounter++
        if (analysisInFlight || frameCounter % analysisIntervalFrames != 0) return

        val image = try {
            frame.acquireCameraImage()
        } catch (e: Exception) {
            null
        } ?: return

        val nv21 = ImageUtils.extractNv21(image)
        image.close() // release camera buffer immediately; nv21 already holds a copy
        if (nv21 == null) return

        analysisInFlight = true
        scope.launch(Dispatchers.Default) {
            try {
                val bitmap = ImageUtils.nv21ToBitmap(nv21)
                if (bitmap != null) {
                    runHandAnalysis(bitmap)
                    runFaceAnalysis(bitmap)
                }
            } finally {
                analysisInFlight = false
            }
        }
    }

    private suspend fun runHandAnalysis(bitmap: Bitmap) {
        val hands = handTracker.detect(bitmap)
        val heartActive = heartDetector.update(hands)
        withContext(Dispatchers.Main) { listener.onHeartGesture(heartActive) }
    }

    private suspend fun runFaceAnalysis(bitmap: Bitmap) {
        val compliment = complimentEngine.analyze(bitmap, 0)
        withContext(Dispatchers.Main) { listener.onCompliment(compliment) }
    }

    companion object {
        fun clamp(v: Float, lo: Float, hi: Float) = max(lo, kotlin.math.min(v, hi))
    }
}
