package com.holoar.cam.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF2979FF)
val DeepSpace = Color(0xFF05070D)
val GlassPanel = Color(0x331A2733)

private val HoloColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = NeonBlue,
    background = DeepSpace,
    surface = GlassPanel,
    onPrimary = DeepSpace,
    onBackground = NeonCyan,
    onSurface = NeonCyan
)

@Composable
fun HoloARTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = HoloColorScheme, content = content)
}
