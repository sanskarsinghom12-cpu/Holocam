package com.holoar.cam.ar

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import java.io.ByteArrayOutputStream

/**
 * Converts an ARCore/CameraX-style YUV_420_888 [Image] into a Bitmap.
 *
 * This is intentionally only called for the throttled analysis path (hand/face
 * detection, a few times per second) -- never for the main render loop, which
 * draws the camera feed straight from the GPU texture. That keeps the expensive
 * YUV->JPEG->Bitmap round trip off the critical rendering path so the AR view
 * itself stays smooth.
 *
 * PRIVACY: the returned Bitmap is only ever handed to the on-device gesture/face
 * analyzers and is not written to disk or kept beyond the current analysis pass.
 */
object ImageUtils {

    data class Nv21Frame(val bytes: ByteArray, val width: Int, val height: Int)

    /**
     * Step 1 (fast, call on the GL thread with the Image still open): copy the YUV
     * planes into a plain byte array so the Image can be closed immediately and
     * doesn't block the camera pipeline while we do the slower JPEG conversion.
     */
    fun extractNv21(image: Image): Nv21Frame? {
        if (image.format != ImageFormat.YUV_420_888) return null

        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        return Nv21Frame(nv21, image.width, image.height)
    }

    /** Step 2 (slower, safe to call off the GL thread): decode into a Bitmap for ML analysis. */
    fun nv21ToBitmap(frame: Nv21Frame): Bitmap? {
        val yuvImage = YuvImage(frame.bytes, ImageFormat.NV21, frame.width, frame.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, frame.width, frame.height), 80, out)
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
}
