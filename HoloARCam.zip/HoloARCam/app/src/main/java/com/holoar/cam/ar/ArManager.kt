package com.holoar.cam.ar

import android.app.Activity
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableException

/**
 * Owns the ARCore [Session] and the list of placed [HoloObject]s.
 * Rendering reads from here every frame; touch input writes to it.
 * Kept free of any Android View/GL code so it's easy to reason about and test.
 */
class ArManager(private val activity: Activity) {

    var session: Session? = null
        private set

    val objects = mutableListOf<HoloObject>()
    var selectedObjectId: Long? = null
        private set

    private var installRequested = false

    /** Call from onResume. Returns false if ARCore isn't installed/supported (caller should degrade gracefully). */
    fun tryResume(): Boolean {
        if (session == null) {
            try {
                when (com.google.ar.core.ArCoreApk.getInstance().requestInstall(activity, !installRequested)) {
                    com.google.ar.core.ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                        installRequested = true
                        return false
                    }
                    com.google.ar.core.ArCoreApk.InstallStatus.INSTALLED -> { /* proceed */ }
                }
                session = Session(activity).apply {
                    val config = Config(this).apply {
                        focusMode = Config.FocusMode.AUTO
                        planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                        lightEstimationMode = Config.LightEstimationMode.DISABLED // keep it lightweight
                        updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                    }
                    configure(config)
                }
            } catch (e: UnavailableException) {
                return false
            } catch (e: Exception) {
                return false
            }
        }
        return try {
            session?.resume()
            true
        } catch (e: CameraNotAvailableException) {
            session = null
            false
        }
    }

    fun pause() {
        session?.pause()
    }

    fun close() {
        objects.forEach { it.anchor.detach() }
        objects.clear()
        session?.close()
        session = null
    }

    fun setDisplayGeometry(width: Int, height: Int, rotation: Int) {
        session?.setDisplayGeometry(rotation, width, height)
    }

    /** Attempts to place a new holographic object at the tapped screen point, on a detected surface. */
    fun placeObjectAt(frame: Frame, screenX: Float, screenY: Float, shape: HoloShape): HoloObject? {
        val hits = frame.hitTest(screenX, screenY)
        val best = hits.firstOrNull { hit ->
            val trackable = hit.trackable
            (trackable is Plane && trackable.isPoseInPolygon(hit.hitPose) && trackable.trackingState == TrackingState.TRACKING) ||
                (trackable is com.google.ar.core.Point)
        } ?: hits.firstOrNull()
        val anchor = best?.createAnchor() ?: return null

        val obj = HoloObject(id = HoloObject.newId(), anchor = anchor, shape = shape)
        objects.add(obj)
        selectedObjectId = obj.id
        return obj
    }

    /** Picks the nearest placed object to a screen tap by projecting anchors to screen space. */
    fun selectObjectNear(frame: Frame, screenX: Float, screenY: Float, viewportWidth: Int, viewportHeight: Int): HoloObject? {
        val camera = frame.camera
        var closest: HoloObject? = null
        var closestDist = SELECT_RADIUS_PX

        for (obj in objects) {
            if (obj.anchor.trackingState != TrackingState.TRACKING) continue
            val screenPoint = projectToScreen(obj, camera, viewportWidth, viewportHeight) ?: continue
            val dx = screenPoint[0] - screenX
            val dy = screenPoint[1] - screenY
            val d = kotlin.math.hypot(dx, dy)
            if (d < closestDist) {
                closestDist = d
                closest = obj
            }
        }
        selectedObjectId = closest?.id
        return closest
    }

    fun selectedObject(): HoloObject? = objects.firstOrNull { it.id == selectedObjectId }

    fun deselect() {
        selectedObjectId = null
    }

    fun removeSelected() {
        val obj = selectedObject() ?: return
        obj.anchor.detach()
        objects.remove(obj)
        selectedObjectId = null
    }

    fun moveSelectedTo(frame: Frame, screenX: Float, screenY: Float) {
        val obj = selectedObject() ?: return
        val hits = frame.hitTest(screenX, screenY)
        val hit: HitResult = hits.firstOrNull { it.trackable is Plane || it.trackable is com.google.ar.core.Point }
            ?: return
        val newAnchor = hit.createAnchor()
        obj.anchor.detach()
        obj.anchor = newAnchor
    }

    fun scaleSelected(factor: Float) {
        val obj = selectedObject() ?: return
        obj.scale = (obj.scale * factor).coerceIn(0.03f, 1.2f)
    }

    fun rotateSelected(deltaDeg: Float) {
        val obj = selectedObject() ?: return
        obj.rotationYDeg = (obj.rotationYDeg + deltaDeg) % 360f
    }

    /** Projects an object's anchor pose to normalized screen pixel coordinates, or null if behind camera. */
    private fun projectToScreen(obj: HoloObject, camera: com.google.ar.core.Camera, w: Int, h: Int): FloatArray? {
        val projmtx = FloatArray(16)
        val viewmtx = FloatArray(16)
        camera.getProjectionMatrix(projmtx, 0, 0.1f, 100f)
        camera.getViewMatrix(viewmtx, 0)

        val pose = obj.anchor.pose
        val world = floatArrayOf(pose.tx(), pose.ty(), pose.tz(), 1f)
        val view = FloatArray(4)
        android.opengl.Matrix.multiplyMV(view, 0, viewmtx, 0, world, 0)
        val clip = FloatArray(4)
        android.opengl.Matrix.multiplyMV(clip, 0, projmtx, 0, view, 0)
        if (clip[3] <= 0f) return null // behind camera
        val ndcX = clip[0] / clip[3]
        val ndcY = clip[1] / clip[3]
        val screenX = (ndcX * 0.5f + 0.5f) * w
        val screenY = (1f - (ndcY * 0.5f + 0.5f)) * h
        return floatArrayOf(screenX, screenY)
    }

    companion object {
        private const val SELECT_RADIUS_PX = 140f
    }
}
