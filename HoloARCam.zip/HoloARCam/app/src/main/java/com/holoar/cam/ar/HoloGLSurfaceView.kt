package com.holoar.cam.ar

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import kotlin.math.atan2

/**
 * Touch model (kept intentionally simple):
 *  - Single tap on empty space -> place a new object of the currently selected shape
 *  - Single tap near an existing object -> select it (does not move it)
 *  - Single-finger drag while an object is selected -> move it along detected surfaces
 *  - Two-finger pinch -> resize the selected object
 *  - Two-finger twist -> rotate the selected object around Y
 */
class HoloGLSurfaceView(context: Context, attrs: AttributeSet? = null) : GLSurfaceView(context, attrs) {

    lateinit var arManager: ArManager
    lateinit var sceneRenderer: HoloSceneRenderer
    var currentShape: HoloShape = HoloShape.CUBE
    var onObjectPlaced: (() -> Unit)? = null
    var onObjectSelected: ((Boolean) -> Unit)? = null

    private var lastTwoFingerAngle: Float? = null
    private var dragging = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            queueEvent { arManager.scaleSelected(detector.scaleFactor) }
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (arManager.selectedObject() != null && e2.pointerCount == 1) {
                dragging = true
                queueEvent {
                    sceneRenderer.latestFrame?.let { frame -> arManager.moveSelectedTo(frame, e2.x, e2.y) }
                }
            }
            return true
        }
    })

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        if (event.pointerCount == 2) {
            val angle = twoFingerAngle(event)
            val last = lastTwoFingerAngle
            if (last != null) {
                var delta = Math.toDegrees((angle - last).toDouble()).toFloat()
                if (delta > 180f) delta -= 360f
                if (delta < -180f) delta += 360f
                queueEvent { arManager.rotateSelected(delta) }
            }
            lastTwoFingerAngle = angle
        } else {
            lastTwoFingerAngle = null
        }

        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            dragging = false
        }

        if (!dragging) gestureDetector.onTouchEvent(event)
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        queueEvent {
            val frame = sceneRenderer.latestFrame ?: return@queueEvent
            val existing = arManager.selectObjectNear(frame, x, y, sceneRenderer.viewportWidth, sceneRenderer.viewportHeight)
            if (existing != null) {
                post { onObjectSelected?.invoke(true) }
                return@queueEvent
            }
            val placed = arManager.placeObjectAt(frame, x, y, currentShape)
            post { onObjectSelected?.invoke(placed != null) }
            if (placed != null) post { onObjectPlaced?.invoke() }
        }
    }

    private fun twoFingerAngle(event: MotionEvent): Float {
        val dx = event.getX(1) - event.getX(0)
        val dy = event.getY(1) - event.getY(0)
        return atan2(dy, dx)
    }
}
