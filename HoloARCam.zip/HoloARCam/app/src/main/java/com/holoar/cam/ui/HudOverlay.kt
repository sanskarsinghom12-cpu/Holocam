package com.holoar.cam.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.holoar.cam.ar.HoloShape
import com.holoar.cam.ui.theme.NeonBlue
import com.holoar.cam.ui.theme.NeonCyan

/** Row of shape choices for placing new holographic objects. */
@Composable
fun ShapePicker(selected: HoloShape, onSelect: (HoloShape) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0x992A2F3A))
            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ShapeChip("Cube", HoloShape.CUBE, selected, onSelect)
        ShapeChip("Box", HoloShape.BOX, selected, onSelect)
        ShapeChip("Energy", HoloShape.ENERGY_BLOCK, selected, onSelect)
    }
}

@Composable
private fun ShapeChip(label: String, shape: HoloShape, selected: HoloShape, onSelect: (HoloShape) -> Unit) {
    val isSelected = shape == selected
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) NeonCyan.copy(alpha = 0.25f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) NeonCyan else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onSelect(shape) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) NeonCyan else Color.White.copy(alpha = 0.7f),
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

/** Small floating delete button, only shown while an object is selected. */
@Composable
fun DeleteFab(visible: Boolean, onDelete: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut(), modifier = modifier) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Color(0xCC2A0F14))
                .border(1.dp, Color(0xFFFF5470), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDelete() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Close, contentDescription = "Remove object", tint = Color(0xFFFF5470))
        }
    }
}

/** Fading text bubble showing the current AI compliment. */
@Composable
fun ComplimentBubble(text: String?, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = text != null, enter = fadeIn(), exit = fadeOut(), modifier = modifier) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x992A2F3A))
                .border(1.dp, NeonBlue.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(text = text ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Pulsing neon holographic heart shown when the two-hand heart gesture is detected. */
@Composable
fun HeartOverlay(visible: Boolean, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "heart-pulse")
    val pulse by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    AnimatedVisibility(visible = visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(300)), modifier = modifier) {
        Text(
            text = "\u2665",
            color = NeonCyan,
            fontSize = 96.sp,
            modifier = Modifier.graphicsLayer {
                scaleX = pulse
                scaleY = pulse
                shadowElevation = 40f
            }
        )
    }
}
