package com.holoar.cam.ar

import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer

/**
 * Draws each [HoloObject] as a glowing wireframe-over-translucent-fill cube.
 * The "glow" is a cheap two-pass trick that stays lightweight on phones:
 *   1. Fill pass: additive-blended translucent faces (very low alpha)
 *   2. Edge pass: bright, thicker-line wireframe on top
 * combined with a subtle sine-based alpha pulse driven by [timeSeconds] for
 * the "soft animation" feel, entirely on the GPU (no per-frame CPU work).
 */
class HoloObjectRenderer {

    private var program = 0
    private var positionAttrib = 0
    private var mvpUniform = 0
    private var colorUniform = 0
    private var alphaUniform = 0

    private lateinit var cubeVertices: FloatBuffer
    private lateinit var edgeIndices: ShortBuffer
    private lateinit var faceIndices: ShortBuffer

    fun createOnGlThread() {
        val vertexShader = GlUtil.loadShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fragmentShader = GlUtil.loadShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
        }
        positionAttrib = GLES20.glGetAttribLocation(program, "a_Position")
        mvpUniform = GLES20.glGetUniformLocation(program, "u_MVP")
        colorUniform = GLES20.glGetUniformLocation(program, "u_Color")
        alphaUniform = GLES20.glGetUniformLocation(program, "u_Alpha")

        // Unit cube centered at origin, -0.5..0.5 on each axis.
        val v = floatArrayOf(
            -.5f, -.5f, -.5f,  .5f, -.5f, -.5f,  .5f, .5f, -.5f,  -.5f, .5f, -.5f,
            -.5f, -.5f,  .5f,  .5f, -.5f,  .5f,  .5f, .5f,  .5f,  -.5f, .5f,  .5f
        )
        cubeVertices = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(v); position(0) }

        val edges = shortArrayOf(
            0,1, 1,2, 2,3, 3,0,   4,5, 5,6, 6,7, 7,4,   0,4, 1,5, 2,6, 3,7
        )
        edgeIndices = ByteBuffer.allocateDirect(edges.size * 2).order(ByteOrder.nativeOrder())
            .asShortBuffer().apply { put(edges); position(0) }

        val faces = shortArrayOf(
            0,1,2, 0,2,3,  4,5,6, 4,6,7,  0,1,5, 0,5,4,
            1,2,6, 1,6,5,  2,3,7, 2,7,6,  3,0,4, 3,4,7
        )
        faceIndices = ByteBuffer.allocateDirect(faces.size * 2).order(ByteOrder.nativeOrder())
            .asShortBuffer().apply { put(faces); position(0) }
    }

    fun draw(objects: List<HoloObject>, viewMatrix: FloatArray, projectionMatrix: FloatArray, timeSeconds: Float) {
        if (objects.isEmpty()) return

        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE) // additive glow
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(program)

        val pulse = 0.75f + 0.25f * kotlin.math.sin(timeSeconds * 2f)
        val modelMatrix = FloatArray(16)
        val mvMatrix = FloatArray(16)
        val mvpMatrix = FloatArray(16)

        for (obj in objects) {
            val pose = obj.anchor.pose
            pose.toMatrix(modelMatrix, 0)
            Matrix.scaleM(modelMatrix, 0, obj.scale, obj.scale, obj.scale)
            Matrix.rotateM(modelMatrix, 0, obj.rotationYDeg, 0f, 1f, 0f)

            Matrix.multiplyMM(mvMatrix, 0, viewMatrix, 0, modelMatrix, 0)
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvMatrix, 0)

            GLES20.glUniformMatrix4fv(mvpUniform, 1, false, mvpMatrix, 0)
            GLES20.glUniform3fv(colorUniform, 1, obj.color, 0)

            cubeVertices.position(0)
            GLES20.glVertexAttribPointer(positionAttrib, 3, GLES20.GL_FLOAT, false, 0, cubeVertices)
            GLES20.glEnableVertexAttribArray(positionAttrib)

            // Fill pass: very faint, gives the "solid hologram" volume feel.
            GLES20.glUniform1f(alphaUniform, 0.08f * pulse)
            faceIndices.position(0)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, 36, GLES20.GL_UNSIGNED_SHORT, faceIndices)

            // Edge pass: bright neon wireframe.
            GLES20.glLineWidth(4f)
            GLES20.glUniform1f(alphaUniform, 0.9f * pulse)
            edgeIndices.position(0)
            GLES20.glDrawElements(GLES20.GL_LINES, 24, GLES20.GL_UNSIGNED_SHORT, edgeIndices)

            GLES20.glDisableVertexAttribArray(positionAttrib)
        }

        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 a_Position;
            uniform mat4 u_MVP;
            void main() {
                gl_Position = u_MVP * a_Position;
            }
        """
        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec3 u_Color;
            uniform float u_Alpha;
            void main() {
                gl_FragColor = vec4(u_Color, u_Alpha);
            }
        """
    }
}
