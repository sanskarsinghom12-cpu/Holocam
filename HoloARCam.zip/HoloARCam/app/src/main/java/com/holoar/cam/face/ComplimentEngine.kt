package com.holoar.cam.face

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.tasks.await

/**
 * Runs on-device face analysis (ML Kit) purely to pick a short, positive compliment.
 *
 * PRIVACY: Every frame is analyzed in memory and immediately discarded. This class never
 * writes a face, landmark, image, or embedding to disk, to a network request, or to any
 * persistent field beyond the single most recent [Mood] used to render the current compliment.
 * No frame, bitmap, or InputImage is ever retained after [analyze] returns.
 */
class ComplimentEngine {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL) // needed for smile/eye-open probabilities
            .setMinFaceSize(0.25f)
            .enableTracking()
            .build()
    )

    data class Mood(val smiling: Boolean, val eyesOpen: Boolean)

    /** Analyzes a single camera frame in place. Returns a compliment string, or null if no face found. */
    suspend fun analyze(bitmap: Bitmap, rotationDegrees: Int): String? {
        val input = InputImage.fromBitmap(bitmap, rotationDegrees)
        val faces: List<Face> = try {
            detector.process(input).await()
        } catch (t: Throwable) {
            return null
        }
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null

        val smiling = (face.smilingProbability ?: 0f) > 0.6f
        val eyesOpen = (face.leftEyeOpenProbability ?: 1f) > 0.5f && (face.rightEyeOpenProbability ?: 1f) > 0.5f

        // face/bitmap/input are local to this function and go out of scope here - nothing retained.
        return pick(Mood(smiling, eyesOpen))
    }

    private fun pick(mood: Mood): String {
        val smilePool = listOf(
            "You have a beautiful smile.",
            "That smile lights up the frame.",
            "Your smile is contagious right now."
        )
        val neutralPool = listOf(
            "You look amazing today.",
            "That's a great angle on you.",
            "You're radiating good energy.",
            "Confidence looks good on you."
        )
        val brightEyesPool = listOf(
            "Your eyes are really striking in this light.",
            "You look wide awake and full of energy."
        )

        val pool = when {
            mood.smiling -> smilePool
            mood.eyesOpen -> brightEyesPool + neutralPool
            else -> neutralPool
        }
        return pool.random()
    }

    fun close() {
        detector.close()
    }
}
