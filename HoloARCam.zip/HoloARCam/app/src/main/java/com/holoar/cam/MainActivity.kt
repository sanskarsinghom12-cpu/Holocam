package com.holoar.cam

import android.Manifest
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.holoar.cam.ar.ArManager
import com.holoar.cam.ar.HoloGLSurfaceView
import com.holoar.cam.ar.HoloSceneListener
import com.holoar.cam.ar.HoloSceneRenderer
import com.holoar.cam.ar.HoloShape
import com.holoar.cam.face.ComplimentEngine
import com.holoar.cam.gesture.HandTracker
import com.holoar.cam.ui.ComplimentBubble
import com.holoar.cam.ui.DeleteFab
import com.holoar.cam.ui.HeartOverlay
import com.holoar.cam.ui.ShapePicker
import com.holoar.cam.ui.theme.DeepSpace
import com.holoar.cam.ui.theme.HoloARTheme
import com.holoar.cam.ui.theme.NeonCyan

class MainActivity : ComponentActivity() {

    private lateinit var arManager: ArManager
    private lateinit var handTracker: HandTracker
    private lateinit var complimentEngine: ComplimentEngine
    private var glSurfaceView: HoloGLSurfaceView? = null

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission.value = granted }

    private val hasCameraPermission = mutableStateOf(false)
    private val arAvailable = mutableStateOf(true)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arManager = ArManager(this)
        handTracker = HandTracker(this)
        complimentEngine = ComplimentEngine()

        hasCameraPermission.value = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

        setContent {
            HoloARTheme {
                Surface(color = DeepSpace, modifier = Modifier.fillMaxSize()) {
                    if (hasCameraPermission.value) {
                        ArCameraScreen(
                            arManager = arManager,
                            handTracker = handTracker,
                            complimentEngine = complimentEngine,
                            arAvailable = arAvailable.value,
                            onSurfaceCreated = { glSurfaceView = it }
                        )
                    } else {
                        PermissionRequestScreen(onRequest = { requestCameraPermission.launch(Manifest.permission.CAMERA) })
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasCameraPermission.value) {
            arAvailable.value = arManager.tryResume()
            glSurfaceView?.onResume()
        }
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView?.onPause()
        arManager.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        arManager.close()
        handTracker.close()
        complimentEngine.close()
    }
}

@Composable
private fun PermissionRequestScreen(onRequest: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResourceCompat(),
            color = Color.White,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Text(
            text = "Tap to grant camera access",
            color = NeonCyan,
            modifier = Modifier.clickableCompat(onRequest)
        )
    }
}

@Composable
private fun ArCameraScreen(
    arManager: ArManager,
    handTracker: HandTracker,
    complimentEngine: ComplimentEngine,
    arAvailable: Boolean,
    onSurfaceCreated: (HoloGLSurfaceView) -> Unit
) {
    val context = LocalContext.current
    val lifecycleScope = (context as ComponentActivity).lifecycleScope

    var heartActive by remember { mutableStateOf(false) }
    var compliment by remember { mutableStateOf<String?>(null) }
    var tracking by remember { mutableStateOf(false) }
    var selectedShape by remember { mutableStateOf(HoloShape.CUBE) }
    var hasSelection by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (arAvailable) {
            // Local aliases avoid any ambiguity between these outer values and the
            // HoloGLSurfaceView's own like-named fields inside the apply{} block below.
            val arManagerRef = arManager
            val handTrackerRef = handTracker
            val complimentEngineRef = complimentEngine

            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    HoloGLSurfaceView(ctx).apply {
                        setEGLContextClientVersion(2)
                        preserveEGLContextOnPause = true

                        val listener = object : HoloSceneListener {
                            override fun onHeartGesture(active: Boolean) { heartActive = active }
                            override fun onCompliment(text: String?) { if (text != null) compliment = text }
                            override fun onTrackingState(tracking_: Boolean) { tracking = tracking_ }
                            override fun onArUnavailable() { /* surfaces via arAvailable on next resume check */ }
                        }
                        val renderer = HoloSceneRenderer(
                            arManagerRef, handTrackerRef, complimentEngineRef, lifecycleScope, listener
                        )
                        this.arManager = arManagerRef
                        this.sceneRenderer = renderer
                        this.currentShape = selectedShape
                        this.onObjectSelected = { hasSelection = it }
                        setRenderer(renderer)
                        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                        onSurfaceCreated(this)
                    }
                },
                update = { view -> view.currentShape = selectedShape }
            )
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = stringResource_arUnsupported(),
                    color = Color.White,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
        }

        // Holographic heart, centered
        HeartOverlay(visible = heartActive, modifier = Modifier.align(Alignment.Center))

        // Compliment bubble, upper area
        ComplimentBubble(
            text = compliment,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp)
        )

        // Tracking hint
        if (arAvailable && !tracking) {
            Text(
                text = "Move your phone slowly to map the space…",
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.align(Alignment.Center).padding(top = 160.dp)
            )
        }

        // Bottom controls
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ShapePicker(selected = selectedShape, onSelect = { selectedShape = it })
            DeleteFab(visible = hasSelection, onDelete = {
                arManager.removeSelected()
                hasSelection = false
            })
        }
    }
}

// Small helpers kept local to avoid extra resource plumbing in this single-activity app.
@Composable
private fun stringResourceCompat(): String =
    androidx.compose.ui.res.stringResource(R.string.camera_permission_rationale)

@Composable
private fun stringResource_arUnsupported(): String =
    androidx.compose.ui.res.stringResource(R.string.ar_unsupported)

private fun Modifier.clickableCompat(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
