package com.holoar.cam.gesture

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Thin wrapper around MediaPipe's HandLandmarker task, configured for up to two
 * hands (needed for the heart-shape gesture) in IMAGE mode so each throttled
 * analysis frame is a simple synchronous call -- no persistent video pipeline.
 *
 * Requires the "hand_landmarker.task" model file bundled in assets/ (see README).
 */
class HandTracker(context: Context) {

    private val landmarker: HandLandmarker = HandLandmarker.createFromOptions(
        context,
        HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(
                BaseOptions.builder()
                    .setModelAssetPath("hand_landmarker.task")
                    .build()
            )
            .setRunningMode(RunningMode.IMAGE)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
    )

    fun detect(bitmap: Bitmap): List<HeartGestureDetector.HandResult> {
        val mpImage = BitmapImageBuilder(bitmap).build()
        val result: HandLandmarkerResult = landmarker.detect(mpImage)
        val handedness = result.handednesses()
        val landmarks = result.landmarks()

        return landmarks.indices.map { i ->
            val label = handedness.getOrNull(i)?.firstOrNull()?.categoryName() ?: "Unknown"
            HeartGestureDetector.HandResult(landmarks[i], label)
        }
    }

    fun close() {
        landmarker.close()
    }
}
