package com.holoar.cam.ar

import com.google.ar.core.Anchor

enum class HoloShape { CUBE, BOX, ENERGY_BLOCK }

/**
 * A single holographic object anchored to a real-world point.
 * The [anchor] is what keeps it fixed in space as the camera moves -- ARCore
 * continuously re-solves the anchor's pose against tracked visual features.
 */
class HoloObject(
    val id: Long,
    var anchor: Anchor,
    var shape: HoloShape,
    var scale: Float = 0.15f,      // meters, roughly a handheld-box size by default
    var rotationYDeg: Float = 0f,  // user-controlled yaw via twist gesture
    var color: FloatArray = floatArrayOf(0f, 0.9f, 1f) // neon cyan (r, g, b)
) {
    companion object {
        private var nextId = 1L
        fun newId(): Long = nextId++
    }
}
