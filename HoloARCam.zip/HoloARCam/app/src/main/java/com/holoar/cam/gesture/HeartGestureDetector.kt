package com.holoar.cam.gesture

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

/**
 * Heuristic two-hand "heart shape" detector built on top of MediaPipe's
 * HandLandmarker output (21 landmarks per hand, normalized 0..1 in image space).
 *
 * Landmark indices used (standard MediaPipe hand model):
 *   0  = wrist
 *   4  = thumb tip
 *   8  = index fingertip
 *   12 = middle fingertip
 *   16 = ring fingertip
 *   20 = pinky fingertip
 *
 * A "heart" is recognized when, across the two detected hands:
 *   1. The thumb tips of both hands are close together (top-center meeting point)
 *   2. The index fingertips of both hands are close together, just above the thumbs
 *   3. The remaining fingers (middle/ring/pinky) are curled in, not extended
 *   4. The two hands are roughly mirrored (one left, one right) rather than stacked
 *
 * This is a lightweight geometric check -- no ML classifier needed -- so it runs
 * comfortably on-device at low latency.
 */
class HeartGestureDetector(
    private val requiredConsecutiveFrames: Int = 3
) {
    private var consecutiveHits = 0

    data class HandResult(
        val landmarks: List<NormalizedLandmark>,
        val handedness: String // "Left" or "Right"
    )

    /** Returns true only after the pose has been held stably for a few frames, to avoid flicker. */
    fun update(hands: List<HandResult>): Boolean {
        val detectedThisFrame = evaluateFrame(hands)
        consecutiveHits = if (detectedThisFrame) consecutiveHits + 1 else 0
        return consecutiveHits >= requiredConsecutiveFrames
    }

    fun reset() {
        consecutiveHits = 0
    }

    private fun evaluateFrame(hands: List<HandResult>): Boolean {
        if (hands.size != 2) return false
        val left = hands.firstOrNull { it.handedness == "Left" } ?: return false
        val right = hands.firstOrNull { it.handedness == "Right" } ?: return false

        val leftThumb = left.landmarks[4]
        val rightThumb = right.landmarks[4]
        val leftIndex = left.landmarks[8]
        val rightIndex = right.landmarks[8]
        val leftWrist = left.landmarks[0]
        val rightWrist = right.landmarks[0]

        // Scale distances relative to hand size so this works at any distance from camera.
        val handSpan = dist(leftWrist.x(), leftWrist.y(), leftIndex.x(), leftIndex.y())
            .coerceAtLeast(0.02f)

        val thumbsClose = dist(leftThumb.x(), leftThumb.y(), rightThumb.x(), rightThumb.y()) < handSpan * 0.9f
        val indexClose = dist(leftIndex.x(), leftIndex.y(), rightIndex.x(), rightIndex.y()) < handSpan * 0.9f

        // Index tips should sit above the thumb tips (smaller y = higher on screen).
        val indexAboveThumbs = leftIndex.y() < leftThumb.y() && rightIndex.y() < rightThumb.y()

        // Wrists should be spread apart (mirrored hands), not touching.
        val wristsSpread = dist(leftWrist.x(), leftWrist.y(), rightWrist.x(), rightWrist.y()) > handSpan * 1.2f

        val leftCurled = isCurled(left.landmarks)
        val rightCurled = isCurled(right.landmarks)

        return thumbsClose && indexClose && indexAboveThumbs && wristsSpread && leftCurled && rightCurled
    }

    /** Middle/ring/pinky fingertips should be closer to the palm than a fully extended finger would be. */
    private fun isCurled(landmarks: List<NormalizedLandmark>): Boolean {
        val wrist = landmarks[0]
        val fingerTipsAndBases = listOf(12 to 9, 16 to 13, 20 to 17) // tip index to base(MCP) index
        var curledCount = 0
        for ((tip, base) in fingerTipsAndBases) {
            val tipDist = dist(landmarks[tip].x(), landmarks[tip].y(), wrist.x(), wrist.y())
            val baseDist = dist(landmarks[base].x(), landmarks[base].y(), wrist.x(), wrist.y())
            // If the fingertip isn't meaningfully farther from the wrist than its base, it's curled.
            if (tipDist < baseDist * 1.3f) curledCount++
        }
        return curledCount >= 2
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float =
        hypot((x1 - x2).toDouble(), (y1 - y2).toDouble()).toFloat()
}
